/* Misc Functions */

function doAjax(){
	
}
