<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
//wc_get_template_part('loop/switch-product', 'view');
?>
<ul class="products">