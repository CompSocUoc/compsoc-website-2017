Lincoln Credits
======
Here are resources we uses in Lincoln project. Thanks for all great works. 
- cbpBGSlideshow: http://tympanus.net/codrops/2013/04/17/background-slideshow/. Licensed under the MIT license by http://www.codrops.com
- FontAwesome: http://fontawesome.io Licensed under GPL
- Isotope: http://isotope.metafizzy.co/ Commercial license
- jQuery Easing: https://github.com/gdsmith/jquery.easing Free to use
- Jquery Imageloaded: https://github.com/desandro/imagesloaded Licensed under MIT license
- Jquery Infinitescroll: https://github.com/paulirish/infinite-scroll Licensed under MIT license
- Jquery Stellar: http://markdalgleish.com/projects/stellar.js Licensed under MIT license
- Jquery Tubular: http://www.seanmccambridge.com/tubular Licensed under MIT license
- Jquery Waypoints: https://github.com/imakewebthings/jquery-waypoints Free to use
- Zoom effect: http://codyhouse.co/gem/pull-out-intro-effect/ Free to use
- Jquery Maskedinput: http://digitalbush.com/projects/masked-input-plugin Free to use
- Jquery Tipsy: http://onehackoranother.com/projects/jquery/tipsy/ Free to use
- Opensave: http://www.gieson.com/Library/projects/utilities/opensave/ Free to use
- ACE code editor: http://ace.c9.io released under the BSD license
- Idangerous.swiper: http://www.idangero.us/swiper/ Licensed under MIT license
- Jquery Inview: https://github.com/protonet/jquery.inview Licensed under MIT license
- Magnific-popup: http://bit.ly/magnific-popup Licensed under MIT license
- Masonry pkgd: http://masonry.desandro.com Licensed under MIT license
- Modernizr: http://modernizr.com Licensed under MIT license
- Sticky mojo: http://mojotech.github.io/stickymojo/ Licensed under MIT license
- jQuery Countdown: https://github.com/hilios/jQuery.countdown Licensed under MIT license
- Jquery CountTo: https://github.com/mhuggins/jquery-countTo Licensed under MIT license
- Jquery easy-pie-chart: http://rendro.github.io/easy-pie-chart/ Licensed under MIT license
- Flexslider: http://www.woothemes.com/flexslider/ Licensed under MIT license
- Jquery mb.YTPlayer: https://github.com/pupunzi/jquery.mb.YTPlayer Licensed under MIT license
- jQuery Parallax: https://github.com/weblinc/jquery-parallax Free to use
- owl carousel: http://owlgraphic.com/owlcarousel/ Free to use
- License for Images in demo sites are provided by Depositphotos.com, Unplash.com and Shutterstock.com

