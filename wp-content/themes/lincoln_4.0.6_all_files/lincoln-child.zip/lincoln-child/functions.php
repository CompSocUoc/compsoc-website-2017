<?php
/**
 * Theme functions for Lincoln child theme
 *
 * @package lincoln
 * @author  lunartheme
 * @link	http://www.lunartheme.com
 */

function k2t_child_enqueue_styles () {
	wp_enqueue_style ('lincoln-child-style', get_stylesheet_directory_uri (). '/style.css');
	wp_enqueue_style ('lincoln-child-learndash', get_stylesheet_directory_uri (). '/learndash/learndash_template_style.css');
}
add_action ('wp_enqueue_scripts', 'k2t_child_enqueue_styles', 100000);

function load_script(){
	wp_enqueue_script( 'k2t-mains-script', get_stylesheet_directory_uri(). '/learndash_template_script.js', array(), '', true );
}
add_action ('wp_enqueue_scripts', 'load_script');
